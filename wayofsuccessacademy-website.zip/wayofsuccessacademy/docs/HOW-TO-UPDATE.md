# 📖 The Way of Success Academy — Website Update Guide
### For Non-Technical Users (No Coding Required!)

---

## 🏗️ Folder Structure

```
wayofsuccessacademy/
│
├── index.html                    ← Main website (DO NOT EDIT MANUALLY)
│
├── content/                      ← ✅ ALL EDITABLE CONTENT IS HERE
│   ├── hero/
│   │   └── hero.json             ← Hero banner, stats, taglines
│   ├── current-affairs/
│   │   ├── weekly.json           ← This week's current affairs
│   │   └── daily.json            ← Today's current affairs
│   ├── notifications/
│   │   └── notifications.json    ← Exam notifications & deadlines
│   ├── courses/
│   │   └── batches.json          ← Course batches & details
│   ├── routine/
│   │   └── routine.json          ← Class timetable
│   ├── youtube/
│   │   └── videos.json           ← YouTube video list
│   ├── mock-tests/
│   │   └── mock-tests.json       ← Mock test information
│   ├── testimonials/
│   │   └── testimonials.json     ← Student success stories
│   ├── faculty/
│   │   └── faculty.json          ← Faculty profiles
│   └── contact/
│       └── contact.json          ← Contact details, social links
│
└── docs/
    └── HOW-TO-UPDATE.md          ← This file!
```

---

## 🔄 How to Ask AI to Update the Website

Just copy-paste these prompts to your AI (Claude) and provide the content:

---

### 📅 Update Weekly Current Affairs

**Prompt to use:**
```
Update the weekly current affairs on my website.
Here is this week's content:

Week: [e.g., May 19–25, 2025]

National:
- [Point 1]
- [Point 2]

West Bengal:
- [Point 1]
- [Point 2]

International:
- [Point 1]

Economy:
- [Point 1]

Sports:
- [Point 1]

Important Days this week:
- May 22: International Biodiversity Day
```

---

### 🗓 Update Daily Current Affairs

**Prompt to use:**
```
Update today's current affairs. Date: [May 20, 2025]

Today's highlights:
1. [News 1]
2. [News 2]
3. [News 3]

One-liner GK:
- [Fact 1]
- [Fact 2]
```

---

### 🔔 Add a New Exam Notification

**Prompt to use:**
```
Add a new exam notification to my website:

Exam: [SSC MTS 2025]
Organization: [Staff Selection Commission]
Total Posts: [8000]
Notification Date: [2025-05-20]
Last Date to Apply: [2025-06-20]
Exam Date: [2025-09-01]
Status: [Application Open]
Apply Link: [https://ssc.gov.in]
Eligibility: [10th Pass]
Age Limit: [18-25 years]
Tag: [New] (options: New / Hot / Latest)
```

---

### 📚 Add / Update a New Batch

**Prompt to use:**
```
Add a new batch to my website:

Batch Name: [WBCS Advanced Batch 2025]
Exam: [WBCS]
Badge: [New Batch] (options: Most Popular / New Batch / Enrolling Now / Limited Seats)
Mode: [Offline + Online]
Language: [Bengali + English]
Duration: [12 Months]
Start Date: [2025-07-01]
Total Seats: [50]
Seats Filled: [10]
Fee: [₹20,000]
EMI: [Available]
Schedule: [Mon–Sat | 7:00 AM – 9:00 AM]
Faculty: [Sudipta Sir]
Subjects: [Bengali, English, GS, Arithmetic, Reasoning]
```

---

### 📅 Change Class Routine

**Prompt to use:**
```
Update the class routine. Effective from: [June 10, 2025]

Monday:
- 7:00 AM – 9:00 AM | WBCS Bengali | Sudipta Sir | WBCS Batch | Room 1
- 6:00 PM – 8:00 PM | SSC Maths | Rajib Sir | SSC Batch | Online

[Continue for each day]
```

---

### ▶ Add New YouTube Videos

**Prompt to use:**
```
Add these new YouTube videos to my website:

Video 1:
Title: [WBCS 2025 History Strategy]
YouTube ID: [xxxxxxxxxxxx] (from the YouTube URL: youtube.com/watch?v=XXXXXX)
Duration: [45:30]
Views: [25K]
Category: [WBCS]
Date: [2025-05-20]
Featured: [Yes/No]
```

---

### 📝 Update Mock Tests

**Prompt to use:**
```
Add / Update a mock test:

Name: [WBCS Prelim Full Mock Test Series 2025]
Exam: [WBCS]
Questions: [200]
Duration: [150 Minutes]
Total Marks: [200]
Frequency: [Every Sunday]
Mode: [Online + Offline]
Price: [₹99/test | ₹599/month]
Free: [No]
Featured: [Yes]
```

---

### 🏆 Add Student Testimonial

**Prompt to use:**
```
Add a new student testimonial:

Name: [Amit Kumar]
Exam: [WBCS 2025]
Rank/Result: [Rank 15]
Batch: [WBCS Foundation Batch 2024]
Quote: [Their testimonial text here...]
Rating: [5]
Year: [2025]
```

---

### 👨‍🏫 Update Faculty

**Prompt to use:**
```
Add a new faculty member:

Name: [Dr. Ratan Ghosh]
Designation: [Science Faculty]
Subjects: [Physics, Chemistry, Biology]
Experience: [8 Years]
Qualification: [M.Sc. Physics, NET Qualified]
Achievements: [Ex-IIT researcher, 300+ selections]
Featured: [Yes]
```

---

### 📞 Update Contact Details

**Prompt to use:**
```
Update the contact details:

Phone: [9088846651]
WhatsApp: [9088846651]
Email: [academy@gmail.com]
Address: [Full address here]
Office Hours: [Mon-Sat: 6AM-9PM, Sun: 9AM-1PM]
```

---

## 🚀 How to Deploy (One-Time Setup)

### Step 1: GitHub
1. Go to [github.com](https://github.com) → Create free account
2. Click "New Repository" → Name it `wayofsuccessacademy`
3. Upload ALL files from this folder

### Step 2: Vercel (Free Hosting)
1. Go to [vercel.com](https://vercel.com) → Create free account
2. Click "Add New Project" → Import from GitHub
3. Select your repository → Click "Deploy"
4. Your website will be live at `https://wayofsuccessacademy.vercel.app`

### Step 3: Custom Domain (Optional)
- Buy domain from GoDaddy / Namecheap (e.g., thewayofsuccessacademy.in)
- In Vercel dashboard → Settings → Domains → Add your domain

---

## ♻️ How to Update After Publishing

1. Make changes to the JSON files in `/content/` folder
2. Go to GitHub → Click the file → Edit (pencil icon) → Paste new content → Commit
3. Vercel automatically updates your live website within 1–2 minutes!

**That's it! No coding needed.**

---

## 📁 JSON File Formats (Reference)

Each JSON file follows a strict format. When asking AI to update, it will maintain these formats automatically. Never delete the structure — only change the values.

---

*Last updated: May 2025 | The Way of Success Academy*
